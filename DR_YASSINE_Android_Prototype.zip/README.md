# DR YASSINE — Android Prototype

Arabic RTL Flutter prototype for initial headache symptom assessment.

## Run
1. Install Flutter.
2. In this folder run:
   flutter pub get
   flutter run

## Important
This prototype is intentionally a triage/education tool, not a diagnostic or prescribing system.
Before publishing, have the clinical logic, red-flag rules, medication content, privacy policy, and regulatory requirements reviewed by qualified medical/legal professionals.
