import 'package:flutter/material.dart';

void main() => runApp(const DrYassineApp());

class DrYassineApp extends StatelessWidget {
  const DrYassineApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'DR YASSINE',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF0879C9),
          primary: const Color(0xFF0879C9),
          secondary: const Color(0xFF12A889),
        ),
        scaffoldBackgroundColor: const Color(0xFFF6FAFD),
        fontFamily: 'sans',
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.white,
          title: const Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.health_and_safety, color: Color(0xFF0879C9)),
              SizedBox(width: 8),
              Text('DR YASSINE', style: TextStyle(fontWeight: FontWeight.bold)),
            ],
          ),
        ),
        body: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(18),
            children: [
              Container(
                padding: const EdgeInsets.all(22),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF0879C9), Color(0xFF12A889)],
                  ),
                  borderRadius: BorderRadius.circular(24),
                ),
                child: const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('صحتك تهمنا',
                        style: TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold)),
                    SizedBox(height: 10),
                    Text(
                      'تقييم أولي للصداع ومساعدتك على فهم الأعراض واتخاذ الخطوة المناسبة.',
                      style: TextStyle(color: Colors.white, fontSize: 16, height: 1.5),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 18),
              FilledButton.icon(
                style: FilledButton.styleFrom(
                  minimumSize: const Size.fromHeight(58),
                  backgroundColor: const Color(0xFF12A889),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const AssessmentPage()),
                ),
                icon: const Icon(Icons.play_arrow_rounded),
                label: const Text('ابدأ تقييم الصداع', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              ),
              const SizedBox(height: 18),
              const InfoCard(
                icon: Icons.warning_amber_rounded,
                title: 'مهم',
                text: 'هذا التطبيق لا يشخّص الأمراض ولا يعوّض الطبيب. إذا ظهرت علامات خطر، اطلب تقييماً طبياً عاجلاً.',
              ),
              const SizedBox(height: 12),
              const InfoCard(
                icon: Icons.medication_outlined,
                title: 'الأدوية',
                text: 'لن يتم تقديم وصفة شخصية. أي معلومات دوائية يجب تأكيدها مع الصيدلي أو الطبيب ووفق النشرة الدوائية.',
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class InfoCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String text;
  const InfoCard({super.key, required this.icon, required this.title, required this.text});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      color: Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: const Color(0xFF0879C9), size: 30),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
                  const SizedBox(height: 5),
                  Text(text, style: const TextStyle(height: 1.5)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class AssessmentPage extends StatefulWidget {
  const AssessmentPage({super.key});
  @override
  State<AssessmentPage> createState() => _AssessmentPageState();
}

class _AssessmentPageState extends State<AssessmentPage> {
  int step = 0;
  int intensity = 5;
  String location = 'الجبهة';
  final Set<String> symptoms = {};

  final locations = ['الجبهة', 'جهة واحدة', 'خلف الرأس', 'حول العينين', 'كامل الرأس'];
  final symptomOptions = [
    'الغثيان أو القيء',
    'حساسية للضوء',
    'حساسية للصوت',
    'تشوش في النظر',
    'حمى',
    'تنميل أو ضعف',
    'ظهور مفاجئ وقوي جداً',
  ];

  bool get danger => symptoms.contains('تنميل أو ضعف') ||
      symptoms.contains('حمى') ||
      symptoms.contains('ظهور مفاجئ وقوي جداً') ||
      symptoms.contains('تشوش في النظر');

  void next() {
    if (step < 2) {
      setState(() => step++);
    } else {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => ResultPage(danger: danger, intensity: intensity),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final titles = ['أين تشعر بالألم؟', 'ما شدة الألم؟', 'هل لديك أعراض أخرى؟'];
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('تقييم الصداع')),
        body: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(
            children: [
              LinearProgressIndicator(
                value: (step + 1) / 3,
                minHeight: 8,
                borderRadius: BorderRadius.circular(8),
              ),
              const SizedBox(height: 22),
              Text('${step + 1} / 3', style: const TextStyle(color: Colors.grey)),
              const SizedBox(height: 8),
              Text(titles[step], style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
              const SizedBox(height: 20),
              Expanded(child: _content()),
              FilledButton(
                onPressed: next,
                style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(56)),
                child: Text(step == 2 ? 'عرض النتيجة' : 'التالي', style: const TextStyle(fontSize: 17)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _content() {
    if (step == 0) {
      return ListView(
        children: locations.map((x) => RadioListTile<String>(
          value: x,
          groupValue: location,
          title: Text(x),
          onChanged: (v) => setState(() => location = v!),
        )).toList(),
      );
    }
    if (step == 1) {
      return Column(
        children: [
          const Text('من 1 إلى 10', style: TextStyle(fontSize: 17)),
          const SizedBox(height: 15),
          Text('$intensity', style: const TextStyle(fontSize: 54, fontWeight: FontWeight.bold)),
          Slider(
            value: intensity.toDouble(),
            min: 1,
            max: 10,
            divisions: 9,
            label: '$intensity',
            onChanged: (v) => setState(() => intensity = v.round()),
          ),
        ],
      );
    }
    return ListView(
      children: symptomOptions.map((x) => CheckboxListTile(
        value: symptoms.contains(x),
        title: Text(x),
        onChanged: (v) => setState(() => v! ? symptoms.add(x) : symptoms.remove(x)),
      )).toList(),
    );
  }
}

class ResultPage extends StatelessWidget {
  final bool danger;
  final int intensity;
  const ResultPage({super.key, required this.danger, required this.intensity});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('نتيجة التقييم')),
        body: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            Card(
              color: danger ? const Color(0xFFFFE8E8) : const Color(0xFFE8F8F0),
              elevation: 0,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
              child: Padding(
                padding: const EdgeInsets.all(22),
                child: Column(
                  children: [
                    Icon(
                      danger ? Icons.error_outline : Icons.check_circle_outline,
                      size: 70,
                      color: danger ? Colors.red : const Color(0xFF12A889),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      danger ? 'توجد علامات تستدعي تقييماً طبياً' : 'لا تظهر علامات خطر واضحة في الإجابات',
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            Text(
              danger
                  ? 'ننصح بعدم الاعتماد على التطبيق لاختيار دواء. تواصل مع طبيب أو اطلب رعاية عاجلة حسب شدة الأعراض.'
                  : 'قد تكون هناك أسباب متعددة للصداع. الراحة، شرب الماء وتجنب المحفزات قد يساعد، وإذا استمر الصداع أو تكرر فاستشر طبيباً.',
              style: const TextStyle(fontSize: 17, height: 1.6),
            ),
            const SizedBox(height: 16),
            Text('شدة الألم المسجلة: $intensity / 10',
                style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 24),
            OutlinedButton.icon(
              onPressed: () => Navigator.popUntil(context, (route) => route.isFirst),
              icon: const Icon(Icons.home_outlined),
              label: const Text('العودة للرئيسية'),
            ),
          ],
        ),
      ),
    );
  }
}
