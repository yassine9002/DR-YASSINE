# DR YASSINE

Flutter Android app for preliminary headache symptom assessment.

Languages: Arabic, French, English.

Includes Instagram contact button.

This version fixes the duplicate `back` map key and the parenthesis syntax issue that caused the previous GitHub Actions build to fail.

Important: This app is not a diagnosis tool and does not replace medical care.
